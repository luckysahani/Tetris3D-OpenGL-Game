#ifndef PLACER_h
#define PLACER_h

#include "glm.h"
#include "common.h"

void place_on_model(GLdouble pos[], Placeable *object);

#endif
