#ifndef COMMON_h
#define COMMON_h

#include "glm.h"

typedef struct {
	GLdouble pos[3];
	GLMmodel *model;
} Placeable;

#endif
